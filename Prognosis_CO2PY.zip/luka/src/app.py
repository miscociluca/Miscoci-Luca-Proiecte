'''
Created on 1 dec. 2017

@author: misco
'''

                                        #Imports
                                        
                                        
from numpy import *
import matplotlib.pyplot as plt
import numpy   as np
import matplotlib.mlab as mlab
from matplotlib.pyplot import plot, scatter
from matplotlib import pylab, mlab
from array import array
from numpy.core.fromnumeric import argmin, argmax
from numpy import linalg
from numpy import matrix
from numpy.linalg.linalg import inv
from sqlite3.test import regression
from pip._vendor.pyparsing import line
from numpy.lib.function_base import histogram, corrcoef
from statistics import variance
from numpy.lib.polynomial import polyfit
from appJar import gui
from numpy.distutils.fcompiler import none
from time import sleep
from appJar.appjar import SubWindow
from numpy.core.defchararray import center

np.set_printoptions(suppress = True,precision=4)


                                        #Source Code
                                        
                                        
tari = open("C:\\Users\\misco\\My Documents\\LiClipse Workspace\\luka\\src\\date\\tari.txt")
line = tari.read()
tarile = line.split()
tararr=np.chararray((218,0))
tararr=tarile
countries=matrix(tararr)
anii=np.loadtxt("C:\\Users\\misco\\My Documents\\LiClipse Workspace\\luka\\src\\date\\anii.txt")
#print(anii,"\n\n")
date_tari=np.loadtxt("C:\\Users\\misco\\My Documents\\LiClipse Workspace\\luka\\src\\date\\date.txt")
#print(date_tari)


def linie_tara(tara):
    for i in range(218):
        if tararr[i]==tara:
            return(i)
def netezire_dublu_exponentiala(x):
    t=np.arange(1,10)
    p=np.empty((9,10,10))
    b=np.empty((9,10,10))
    er=np.empty((9,10,10))
    meaner=np.empty((10,10))
    for i in range(0,10):
        for j in range(0,10):
            p[0][i][j]=x[0]
    for i in range(0,10):
        for j in range(0,10):
            b[0][i][j]=x[1]-x[0]
    for t in range(1,9):
        for j in range(0,10):
            for k in range(0,10):
                p[t][j][k]=0.1*(j+1)*x[t]+0.1*((10-(j+1))*(p[t-1][j][k]+b[t-1][j][k]))
                b[t][j][k]=0.1*(k+1)*((p[t][j][k])-(p[t-1][j][k]))+0.1*((10-(k+1))*b[t-1][j][k])
    for t in range(0,9):
        for j in range(0,10): 
            for k in range(0,10): 
                er[t][j][k]=(x[t]-p[t][j][k])**2        
    for t in range(0,10):        
        for j in range(0,10):
            meaner=[t][k]=np.mean(er[:][j][k])         
    p=np.empty((9))
    b=np.empty((9))
    p[0]=x[0]
    b[0]=x[1]-x[0]
    for t in range(1,9):
        p[t]=0,9*x[t]+0,1*(p[t-1]+b[t-1])
        b[t]=0,5*(p[t]-p[t-1])+0,5*(b[t-1])
    F=np.empty((2))
    F[0]=p[7]
    for t in range(0,2): 
        F[t+1]=p[8]+(t+1)*b[8]
    t1=np.array([10,11])
    plt.plot(t,x,'*',t,p,'o-')
    plt.plot(t1,F,'y-')
    plt.show()
def medie_mobila_ponderata(x):  
    m3=np.zeros(9)
    e3=np.zeros(9)
    m4=np.zeros(9)
    e4=np.zeros(9)
    m5=np.zeros(9)
    e5=np.zeros(9)
    m6=np.zeros(9)
    e6=np.zeros(9)
    for i in range(3,9):
        m3[i]=(3*x[i-1]+2*x[i-2]+x[i-3])/6
    for i in range(3,9):    
        e3[i]=(x[i]-m3[i])**2
    for i in range(4,9):
        m4[i]=(4*x[i-1]+3*x[i-2]+2*x[i-3]+x[i-4])/10  
    for i in range(4,9):  
        e4[i]=(x[i]-m4[i])**2 
    for i in range(5,9):
        m5[i]=(5*x[i-1]+4*x[i-2]+3*x[i-3]+2*x[i-4]+x[i-5])/15  
    for i in range(5,9):  
        e5[i]=(x[i]-m5[i])**2 
    for i in range(6,9):
        m6[i]=(6*x[i-1]+5*x[i-2]+4*x[i-3]+3*x[i-4]+2*x[i-5]+x[i-6])/21   
    for i in range(6,9):  
        e6[i]=(x[i]-m6[i])**2 
    Mse3=(9/6)*np.mean(e3)
    Mse4=(9/5)*np.mean(e4)
    Mse5=(9/4)*np.mean(e5)
    Mse6=(9/3)*np.mean(e6)
    a=[Mse3,Mse4,Mse5,Mse6]
    b=np.around(a,decimals=4)
    launch2(b)
    print(b)
    if(Mse3<Mse4 and Mse3<Mse5 and Mse3<Mse6):
        p10=(x[6]+x[7]+x[8])/3
        p11=(x[7]+x[8]+p10)/3 
        m3s=m3[3:]
        t0=np.arange(1,10) 
        t1=np.arange(4,10)
        t2=np.arange(9,12) 
        plt.plot(t0,x,'k*-')
        plt.plot(t1,m3s,'ko-')
        plt.plot(t2,np.array([m3s[1],p10,p11]),'o-')
        plt.show()
    if(Mse4<Mse3 and Mse4<Mse5 and Mse4<Mse6):
        p10=(x[5]+x[6]+x[7]+x[8])/4
        p11=(x[6]+x[7]+x[8]+p10)/3 
        m3s=m3[4:]
        t0=np.arange(1,10) 
        t1=np.arange(5,10)
        t2=np.arange(9,12)
        plt.plot(t0,x,'k*-')
        plt.plot(t1,m3s,'ko-')
        plt.plot(t2,np.array([m3s[1],p10,p11]),'o-')
        plt.show()    
    if(Mse5<Mse4 and Mse5<Mse3 and Mse5<Mse6):
        p10=(x[4]+x[5]+x[6]+x[7]+x[8])/5
        p11=(x[5]+x[6]+x[7]+x[8]+p10)/5
        m3s=m3[5:]
        t0=np.arange(1,10) 
        t1=np.arange(6,10)
        t2=np.arange(9,12)
        plt.plot(t0,x,'k*-')
        plt.plot(t1,m3s,'ko-')
        plt.plot(t2,np.array([m3s[1],p10,p11]),'o-')
        plt.show()    
    if(Mse6<Mse4 and Mse6<Mse5 and Mse6<Mse3):
        p10=(x[3]+x[4]+x[5]+x[6]+x[7]+x[8])/6
        p11=(x[4]+x[5]+x[6]+x[7]+x[8]+p10)/6 
        m3s=m3[6:]
        t0=np.arange(1,10) 
        t1=np.arange(7,10)
        t2=np.arange(9,12)
        plt.plot(t0,x,'k*-')
        plt.plot(t1,m3s,'ko-')
        plt.plot(t2,np.array([m3s[1],p10,p11]),'o-')
        plt.show()   
                 

#medie_mobila_ponderata(x)

def medie_mobila(x):  
    m3=np.zeros(9)
    e3=np.zeros(9)
    m4=np.zeros(9)
    e4=np.zeros(9)
    m5=np.zeros(9)
    e5=np.zeros(9)
    m6=np.zeros(9)
    e6=np.zeros(9)
    for i in range(3,9):
        m3[i]=(x[i-1]+x[i-2]+x[i-3])/3
    for i in range(3,9):    
        e3[i]=(x[i]-m3[i])**2
    for i in range(4,9):
        m4[i]=(x[i-1]+x[i-2]+x[i-3]+x[i-4])/4  
    for i in range(4,9):  
        e4[i]=(x[i]-m4[i])**2 
    for i in range(5,9):
        m5[i]=(x[i-1]+x[i-2]+x[i-3]+x[i-4]+x[i-5])/5  
    for i in range(5,9):  
        e5[i]=(x[i]-m5[i])**2 
    for i in range(6,9):
        m6[i]=(x[i-1]+x[i-2]+x[i-3]+x[i-4]+x[i-5]+x[i-6])/6   
    for i in range(6,9):  
        e6[i]=(x[i]-m6[i])**2 
        
    Mse3=(9/6)*np.mean(e3)
    Mse4=(9/5)*np.mean(e4)
    Mse5=(9/4)*np.mean(e5)
    Mse6=(9/3)*np.mean(e6)
    a=[Mse3,Mse4,Mse5,Mse6]
    b=np.around(a,decimals=4)
    launch2(b)
    print(b)
    if(Mse3<Mse4 and Mse3<Mse5 and Mse3<Mse6):
        p10=(x[6]+x[7]+x[8])/3
        p11=(x[7]+x[8]+p10)/3 
        m3s=m3[3:]
        t0=np.arange(1,10) 
        t1=np.arange(4,10)
        t2=np.arange(9,12) 
        plt.plot(t0,x,'k*-')
        plt.plot(t1,m3s,'ko-')
        plt.plot(t2,np.array([m3s[1],p10,p11]),'o-')
        plt.show()
    if(Mse4<Mse3 and Mse4<Mse5 and Mse4<Mse6):
        p10=(x[5]+x[6]+x[7]+x[8])/4
        p11=(x[6]+x[7]+x[8]+p10)/3 
        m3s=m3[4:]
        t0=np.arange(1,10) 
        t1=np.arange(5,10)
        t2=np.arange(9,12)
        plt.plot(t0,x,'k*-')
        plt.plot(t1,m3s,'ko-')
        plt.plot(t2,np.array([m3s[1],p10,p11]),'o-')
        plt.show()     
    if(Mse5<Mse4 and Mse5<Mse3 and Mse5<Mse6):
        p10=(x[4]+x[5]+x[6]+x[7]+x[8])/5
        p11=(x[5]+x[6]+x[7]+x[8]+p10)/5
        m3s=m3[5:]
        t0=np.arange(1,10) 
        t1=np.arange(6,10)
        t2=np.arange(9,12)
        plt.plot(t0,x,'k*-')
        plt.plot(t1,m3s,'ko-')
        plt.plot(t2,np.array([m3s[1],p10,p11]),'o-')
        plt.show()
   
    if(Mse6<Mse4 and Mse6<Mse5 and Mse6<Mse3):
        p10=(x[3]+x[4]+x[5]+x[6]+x[7]+x[8])/6
        p11=(x[4]+x[5]+x[6]+x[7]+x[8]+p10)/6 
        m3s=m3[6:]
        t0=np.arange(1,10) 
        t1=np.arange(7,10)
        t2=np.arange(9,12)
        plt.plot(t0,x,'k*-')
        plt.plot(t1,m3s,'ko-')
        plt.plot(t2,np.array([m3s[1],p10,p11]),'o-')
        plt.show()       
def serie_temp(tara):
    a=linie_tara(tara)   
    array_date=np.array(date_tari[a,:])
    medie_mobila(array_date) 
                                    #Graphical User Interface
                                    
                              
nume="luca"
parola="123"
usr=""
pwd=""
country=""
app=gui(" Application","600x400");
app.setBgImage("C:\\Users\\misco\\My Documents\\LiClipse Workspace\\luka\\src\\poza\\luk.png")
app.addLabel("title","CO2 Emissions")
app.setLabelWidth("title",10)
app.setLabelAlign("title", "center")
app.addLabelEntry("Username")
app.addLabelSecretEntry("Password")
def get(btn):
    r=app.getOptionBox("OPTIONS")
    country = app.getOptionBox("Countries:")
    if r["Simple Plot"]is True:
        a=linie_tara(country)   
        array_date=np.array(date_tari[a,:])
        t0=np.arange(1,10)    
        plt.plot(t0,array_date,'k*-')
        plt.show()
    if r["Media mobila"]is True:   
        serie_temp(country)
    if r["Media ponderata"]is True:    
        a=linie_tara(country)   
        array_date=np.array(date_tari[a,:])
        medie_mobila_ponderata(array_date)
def launch2(a):
    app.startSubWindow("two",modal=True)
    app.setBg("green")
    app.setGeometry("400x300")
    app.setSubWindowLocation("two",750,120)
    app.setTitle("MSE")
    app.addTextArea("mse")
    app.setTextArea("mse","         Valori MSE\n")
    app.setTextArea("mse","Mse3: ")
    app.setTextArea("mse",a[0])
    app.setTextArea("mse","\n")
    app.setTextArea("mse","Mse4: ")
    app.setTextArea("mse",a[1])
    app.setTextArea("mse","\n")
    app.setTextArea("mse","Mse5: ")
    app.setTextArea("mse",a[2])
    app.setTextArea("mse","\n")
    app.setTextArea("mse","Mse6: ")
    app.setTextArea("mse",a[3])
    app.setTextArea("mse","\n")
    app.setTextArea("mse","Minim: ")
    app.setTextArea("mse",np.min(a))
    app.showSubWindow("two")  
    app.stopSubWindow()
def launch():
    app.startSubWindow("one", modal=True)
    app.setBg("blue")
    app.setGeometry("700x400")
    app.setTitle("Main")
    app.setFont(20)
    app.addLabelOptionBox("Countries:",tararr)
    app.addTickOptionBox("OPTIONS", ["Simple Plot", "Media mobila","Media ponderata","Netezire Dublu Exponentiala"])
    app.addButton("RUN", get)
    app.addNamedButton("CLOSE", "one", app.hideSubWindow)
    app.showSubWindow("one")
def updateMeter():
    for i in range(100):
        app.setMeter("progress",i)
            
def press(butt):
    if butt == "Cancel":
        app.stop()
    else:
        usr = app.getEntry("Username")
        pwd = app.getEntry("Password")
        if usr==nume and pwd==parola:
            app.addLabel("log","Login succsessfully")
            app.setLabelBg("log","green") 
            app.addStatus()
            app.setStatus("New Status..")
            app.setTransparency(0)
            launch()
            print("User:", usr, "Pass:", pwd)
        else:
            app.addLabel("log2","Login failed!Try again!",17)    
app.addButtons(["Submit", "Cancel"], press)   
app.go()





